# Source review and provenance

## Primary project input

The user attached `implement-rfc.zip` from BPR in this conversation. That attachment is authoritative for the requested seed; no other project's skill or online implementation was substituted.

- Original archive SHA-256: `1043f25111969b1270870b566a705f22e6f6cb253d1a4ff0de3a0c2461cc4a90`.
- Clean payload: 39 regular files, 437,236 bytes before any project adaptation.
- Exclusions: archive directory entries, `__MACOSX`, AppleDouble `._*`, `__pycache__` and Python bytecode.
- Every retained source file is byte-for-byte unchanged in `seeds/AgentSkills/skills/implement-rfc/`.
- `SEED-PROVENANCE.json` records retained-file hashes and exclusions. This is source-import provenance, not an implementation-verification artifact.

## Findings that materially change the implementation plan

| Supplied file | Observed behavior | Required treatment |
|---|---|---|
| `SKILL.md`, `README.md` | Workflow declares exactly two project-specific files: `config/project.json`, `references/project.md`; porting currently means copying the directory. | Preserve workflow semantics; introduce external consumer-project context without a fork per project. |
| `config/project.json`, `references/project.md` | Name BetterPullReview, its repository, issue prefix, architecture, structure gate and attended-review skill. | Use supplied MASK/AgentSkills project facts for bootstrapping. Move BPR facts to an example/provenance location in the shared version; never use them as an implicit fallback for another project. |
| `scripts/project_config.py` | `SKILL_DIR` resolves the script path; `PROJECT_PATH` points inside the skill; `repo_root()` returns `SKILL_DIR.parents[2]`. | Resolve the consumer from explicit arguments / environment / Git CWD, independently of asset location. |
| `scripts/render_runtime_adapters.py` | Reads project facts from the skill even with `--repo-root`; writes `.claude/skills/implement-rfc/SKILL.md` and `.agents/skills/implement-rfc/generated/*`. | Shared mode must suppress the shim and move per-project manifests to `.mask/generated/implement-rfc/`; refuse all writes through linked skill roots. |
| `scripts/validate_portable_agents.py` | Assumes project-local display paths and a generated manifest inside the skill. | Separate portable-source validation from consumer adapter validation. |
| `scripts/codex_lane.py`, `codex_station.py`, `launch_remote_station.py`, `station_lease.py` | Load project config at module import; some independently infer a root from the skill path. | Defer consumer context until command invocation. Optional remote helpers must preserve their boundaries; MASK gains no remote orchestration. |
| `scripts/remote_station_guard.py` | Looks up `config/project.json` beneath the repository-local skill. | Use the same consumer-context resolver; never consult another project's config. |
| `references/pack-lifecycle.md` | Import on main; reconcile live IDs; retain original packet as provenance; one lane per pack; tracker/counter/reservation writes belong to the integrator. | Provide import mappings, local boards and closeout cards. Preserve the attachment's execution process. |
| `tests/test_project_config.py` | Asserts the legacy `SKILL_DIR.parents[2]` relationship. | Update tests with explicit consumer fixtures and preserve a deliberate legacy local-copy case, not the broken shared assumption. |
| `tests/test_render_runtime_adapters.py::test_portable_sources_name_no_project` | Forbids every case-insensitive substring of the consumer name. With MASK it rejects legitimate WebSocket `mask` variables; with AgentSkills it rejects the public `agentskills.io` documentation URL. | Replace the blanket substring rule with scoped coupling checks and positive/negative fixtures in ASK-0003. Keep genuine BPR facts and wrong-consumer fallback checks; do not rename the product or weaken isolation to silence the test. |

The BPR archive does **not** include the BPR repository's `scripts/allocate_issue_id.py` or `scripts/verify_documentation.py`, and there is no complete BPR source checkout in this task. The packet supplies small bootstrap tracker utilities and project-specific rules for the two new repositories rather than assuming missing BPR scripts exist.

A disposable bootstrap smoke run verified both supplied project contexts and original renderer entrypoints. The original project-config suite passes 6/6 in each context. The original adapter suite passes 8/9 in each; the inherited substring linter fails for the ordinary tokens described above. This is a known adaptation task, not a claim that the unmodified seed has a fully green portability suite. See PACK-VALIDATION.md.

## Live-repository boundary

Metadata lookups for `MikeMarcin/ManageAgentSkills` and `MikeMarcin/AgentSkills` returned 404. Their existence, contents, branches and permissions are therefore **unverified**, not asserted empty. No repository was created, modified, renamed, made public, or pushed while producing this pack. Live IDs and baseline SHAs must be assigned at import.

## Technical verification boundary

Official documentation was checked for local skill discovery/symlink behavior, Python's symlink API and Windows prerequisites, subprocess behavior, and Git fast-forward semantics. See REFERENCES.md. No claim is made that the future MASK program passes tests: it has not been implemented here. No Windows/macOS runtime results are fabricated.
