#!/usr/bin/env python3
"""Validate the downloaded RFC packet. Does NOT test a MASK implementation."""
from __future__ import annotations
import argparse,hashlib,json,re,sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();root=a.root.resolve()
    manifest=json.loads((root/'PACK-MANIFEST.json').read_text());issues=manifest['cards'];rfcs=manifest['rfcs'];errors=[]
    lookup={(c['repository'],c['id']):c for c in issues};rlookup={(r['repository'],r['id']):r for r in rfcs}
    if len(lookup)!=len(issues):errors.append('duplicate cards')
    if len(rlookup)!=len(rfcs):errors.append('duplicate RFCs')
    def exists(path):
        if not (root/path).is_file():errors.append('missing file '+path);return False
        return True
    for path in manifest['inventory']:
        exists(path)
    for r in rfcs:
        if exists(r['path']):
            body=(root/r['path']).read_text()
            for ac in r['acceptance_ids']:
                if body.count('**'+ac+'**')!=1:errors.append('acceptance ID definition '+ac)
    graph={}
    for c in issues:
        k=(c['repository'],c['id']);edges=[]
        if (c['repository'],c['rfc']) not in rlookup:errors.append('missing card RFC '+c['id'])
        if exists(c['path']):
            body=(root/c['path']).read_text()
            if 'id: '+c['id']+'\n' not in body:errors.append('card id mismatch '+c['id'])
            lane=Path(c['path']).parent.name
            expected={'10-backlog':'Backlog','20-ready':'Ready','21-ready-win':'Ready','22-ready-mac':'Ready','23-ready-lin':'Ready'}
            if 'status: '+expected.get(lane,'INVALID')+'\n' not in body:errors.append('initial lane/status '+c['id'])
            if c['closeout']:
                for ac in rlookup[(c['repository'],c['rfc'])]['acceptance_ids']:
                    if '| '+ac+' |' not in body:errors.append('closeout missing '+ac)
        for d in c['depends_on']:edges.append((c['repository'],d))
        for d in c['external_depends_on']:edges.append(tuple(d.split(':',1)))
        for e in edges:
            if e not in lookup:errors.append('unresolved dependency '+str(e))
        graph[k]=edges
    seen=set();active=set()
    def walk(k):
        if k in active:errors.append('dependency cycle '+str(k));return
        if k in seen or k not in graph:return
        active.add(k)
        for e in graph[k]:walk(e)
        active.remove(k);seen.add(k)
    for k in graph:walk(k)
    for r in rfcs:
        matching=[c for c in issues if c['repository']==r['repository'] and c['rfc']==r['id'] and c['closeout']]
        if len(matching)!=1:errors.append('closeout count '+r['id'])
    for name in ['ManageAgentSkills','AgentSkills']:
        cfg=root/'repositories'/name/'.mask/skill-config/implement-rfc/project.json'
        obj=json.loads(cfg.read_text())
        if obj['origin_repo_name']!=name:errors.append('wrong project context '+name)
        nxt=(root/'repositories'/name/'docs/issues/NEXT_ID').read_text().strip()
        high=max(int(c['id'].rsplit('-',1)[1]) for c in issues if c['repository']==name)
        if int(nxt.rsplit('-',1)[1])<=high:errors.append('NEXT_ID '+name)
    prov=json.loads((root/'SEED-PROVENANCE.json').read_text());base=root/'seeds/AgentSkills/skills/implement-rfc'
    for f in prov['files']:
        path=base/f['path']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=f['sha256']:errors.append('seed changed '+f['path'])
    actual=[x for x in base.rglob('*') if x.is_file()]
    if len(actual)!=prov['retained_file_count']:errors.append('seed file count')
    for x in root.rglob('*'):
        if '__pycache__' in x.parts or '__MACOSX' in x.parts or x.name.startswith('._'):errors.append('transient artifact '+str(x))
        if x.suffix=='.json':
            try:json.loads(x.read_text(encoding='utf-8'))
            except (ValueError,UnicodeError):errors.append('invalid JSON '+str(x))
    for p in (root/'templates/examples').glob('result-*.json'):
        v=json.loads(p.read_text());required={'schema_version','tool','tool_version','command','ok','dry_run','changed','would_change','transaction','data','actions','warnings','error'}
        if set(v)!=required:errors.append('envelope keys '+p.name)
        if v['dry_run'] and v['changed']:errors.append('dry-run claimed change '+p.name)
        if v['ok'] and (v['error'] is not None or v['transaction']=='partial'):errors.append('false success '+p.name)
        if not v['ok'] and v['error'] is None:errors.append('missing error '+p.name)
    print(json.dumps({'packet_valid':not errors,'rfcs':len(rfcs),'cards':len(issues),'seed_files':len(actual),'errors':errors},indent=2))
    return 1 if errors else 0

if __name__=='__main__':raise SystemExit(main())
