# Requested implementation order

This is the packet's import-time order. After import, live card dependencies and integration-commit handoffs are authoritative. Do not create a second mutable progress checklist from this document.

| Order | Repository / RFC | Local cards | Deliverable / handoff |
|---:|---|---|---|
| 1 | AgentSkills / RFC-ASK-0001 | ASK-0001–0004 | Supplied skill imported first; one shared consumer-safe workflow and safe optional renderer |
| 2 | ManageAgentSkills / RFC-MASK-0001 | MASK-0001–0004 | JSON CLI, strict declarations, passive catalog and machine-local registry |
| 3 | ManageAgentSkills / RFC-MASK-0002 | MASK-0005–0010 | Planner, owned symlink effects, recovery/adopt/doctor and native safety evidence |
| 4 | ManageAgentSkills / RFC-MASK-0003 | MASK-0011–0014 | Explicit source updates, launchers and independent self update |
| 5 | AgentSkills / RFC-ASK-0002 | ASK-0005–0006 | Agent-facing management skill, added second and verified against the CLI |
| 6 | ManageAgentSkills / RFC-MASK-0004 | MASK-0015–0018 | Bootstrap retirement, two-repository dogfood, native launchers and v1 readiness |

## Cross-repository dependencies

`MASK-0001` cannot be claimed until `AgentSkills:ASK-0004` is integrated. `ASK-0005` requires `ManageAgentSkills:MASK-0014`. `MASK-0015` requires `AgentSkills:ASK-0006`. Their `external_depends_on` fields are explicit; local allocators and the local board audit do not pretend they can modify another repository.

Record each external dependency's source repo, live card/RFC ID, integration commit and acceptance boundary in the consuming card. Recheck that commit exists in the authorized source checkout; do not accept a remembered chat summary as completion. If IDs are renumbered, the integrators update both LIVE_IMPORT mappings and consumer references.

## Platform-ready cards

MASK-0008 and MASK-0016 are Windows-native; MASK-0009 and MASK-0017 are macOS-native. Initially they are Backlog with dependencies. When ready, move them to `21-ready-win` or `22-ready-mac`. No scheduling dates are imposed. Reuse unchanged native results; the final cards focus on new launcher and end-to-end behavior rather than repeating the whole safety suite.

## Integration authority

One local work lane per pack/repository is sufficient. Do not create a worktree for every card. Only the integrator on main imports, reserves IDs, advances counters and confirms Auto-Verified after integration. Existing portable remote helpers are not a reason to build or configure fleet orchestration.
