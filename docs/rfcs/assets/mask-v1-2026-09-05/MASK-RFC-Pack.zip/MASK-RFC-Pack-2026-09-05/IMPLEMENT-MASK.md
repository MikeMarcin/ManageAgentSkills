# Agent handoff: implement MASK

Implement the attached MASK RFC pack, using the supplied BPR portable `implement-rfc` workflow and the actual live RFC/issue boards.

The product is **MASK — Manage Agent SKills**, executable `mask`.

Use exactly two repositories:

```text
MikeMarcin/ManageAgentSkills  — the Python program
MikeMarcin/AgentSkills       — private canonical skill collection
```

Read `START-HERE.md`, `DECISIONS.md`, `SOURCE-REVIEW.md`, `PACK-MANIFEST.json` and `IMPLEMENTATION-ORDER.md` before modifying source. The first AgentSkills skill must be the clean supplied implement-rfc seed; do not replace it with a freshly invented workflow. The original seed is project-local by design: bootstrap it with the provided two-file project customization, then implement RFC-ASK-0001 so the canonical shared skill selects consumer-local project facts and never overwrites shared SKILL.md through the old Claude shim renderer.

Import the pack on main with live collision-free IDs and actual baseline SHAs. Preserve unrelated work and existing instructions. The attached packet is provenance, not a second live task board. Each repository retains its own cards; cross-repository dependencies are integration-commit handoffs, not remote board mutations by a worker.

Build the smallest dependency-free Python 3.11+ CLI described in the RFCs. Routine agent management must use noninteractive CLI operations and versioned JSON, including parser failures, no-op reporting, stable error codes, prospective dry-runs, plan hashes, exact-set versus incremental edits, and safe recovery. Do not ask the agent to edit state.json or recreate symlinks manually during routine use.

Preserve these hard boundaries: one source, symlink-only deployment, no recursive deletion, no unmanaged overwrite, no force mode, no automatic merges/pushes, no credential store, no background synchronization. Treat separate source/program update commands as distinct scopes. Candidate source revisions must be validated against every registered project's live declaration before fast-forward. Report partial effects honestly and retain minimal recoverable intent.

Implement in the pack order: AgentSkills RFC-ASK-0001; MASK RFC-MASK-0001/0002/0003; AgentSkills RFC-ASK-0002; MASK RFC-MASK-0004. Add manage-agent-skills only after implement-rfc and after checking examples against the real CLI. Dogfood only the two named repositories unless another project is explicitly authorized. Never delete or migrate existing BPR/PlaceOfMind skill trees implicitly.

Use focused tests and one direct selected CLI path per acceptance boundary. Run native Windows/macOS symlink and launcher checks for the support claims; report unavailable lanes without a fabricated pass. Do not add a broad test matrix, proof-of-proof artifacts, a GUI, a package-manager framework or a fleet service. Use temporary local bare remotes and disposable fixture projects for Git/filesystem testing, not real private repositories as test fixtures.

If GitHub repositories or credentials are unavailable, finish all independent local implementation, name the genuine access blocker, and preserve the live next-slice handoff. Do not infer a 404 means the repo is nonexistent. Creating/publishing repos or altering credentials requires explicit authority.

At closeout give completed live cards/commits, actual checks and platforms, the two-repo integration handoffs, bootstrap cutover status and remaining limitations. Do not claim the packet itself constitutes a completed MASK implementation.
