# Bootstrap support, not MASK runtime

The scripts in `bootstrap/scripts/` supply the two tracker hooks expected by the attached implement-rfc process in repositories that do not already have equivalents. Copy/reconcile them to each target's `scripts/` during the import planning slice. They are ordinary repository development utilities and are **not** the finished MASK CLI.

`project-context/<repository>/` contains the only two substitutions made inside an initial real-directory bootstrap executor: config/project.json and references/project.md. The canonical shared version later reads the same facts from `.mask/skill-config/implement-rfc/` without copying the skill per consumer.

The allocator requires the integrator's main branch, never recycles IDs, and burns a range if a crash advances the counter before the receipt is written. Its short-lived exclusive reservation lock is separate from the MASK runtime's OS lock. A stale bootstrap allocator lock is an integrator diagnostic, never authority to delete user content. The verifier checks a deliberately small Markdown/frontmatter convention used by this packet and excludes retained assets from live RFC discovery.

These scaffolds must be reconciled with existing project tooling rather than overwriting it. Normal agents invoke MASK's completed CLI for skill management; the bootstrap exception ends at the recorded cutover.
