# Start here: build MASK using the supplied workflow

This is an implementation handoff for an agent with local shell/Git access. The current request produced the packet only; no GitHub or real local skill configuration has been modified.

## 1. Establish the two real checkouts

The names are fixed:

- `MikeMarcin/ManageAgentSkills` — MASK program, CLI schemas, tests and product RFCs.
- `MikeMarcin/AgentSkills` — private canonical skill collection; implement-rfc first.

Inspect existing checkouts, branch and dirty state. Use `gh repo view`/ordinary Git with existing authorized authentication to distinguish accessible repositories from a permission failure. Do not treat a 404 as proof a repository is absent. Reuse existing repositories; do not recreate, overwrite or make them public. Repository creation or permission changes require the user's explicit authority. If creation is authorized and truly needed, choose private by default and preserve the exact names.

Use ordinary `git clone` for initial checkouts, e.g. `git@github.com:MikeMarcin/AgentSkills.git` and `git@github.com:MikeMarcin/ManageAgentSkills.git`. Resolve absolute local paths on this machine; do not assume a home-directory name or drive. Select Python 3.11+ once and use that interpreter consistently. `python` below means that selected interpreter.

## 2. Bootstrap the existing implement-rfc executor before MASK exists

There is an intentional short-lived bootstrap copy per repository. It is **not** the final distribution design.

In each target checkout, after inventorying existing instructions and skill/adapter paths:

1. If there is no Git baseline, create a small initial repository/instructions commit on main first. Never invent a baseline SHA.
2. Copy the packet's clean `seeds/AgentSkills/skills/implement-rfc/` into that checkout's `.agents/skills/implement-rfc/` as real files. Do not overwrite an existing directory or symlink. If one exists, compare/reconcile under explicit authority or use its already-configured matching workflow; preserve unrelated content.
3. Replace **only within this newly staged bootstrap copy** `config/project.json` and `references/project.md` with the matching files under `bootstrap/project-context/ManageAgentSkills/` or `.../AgentSkills/`. These are the original skill's supported per-project customization points.
4. Read the customized SKILL.md/project rules and this packet's order before any source implementation. Verify the root/repository identity is the intended consumer.
5. The native role adapters are optional. Before using the original renderer, inventory every emitted path and require those paths to be absent or explicitly owned bootstrap outputs. Run it only when both skill roots are **not shared symlinks**. Otherwise use the primary local agent following SKILL.md directly and defer adapter generation until RFC-ASK-0001 provides the safe renderer.
6. Never run the unmodified original renderer after MASK installs symlinks: it writes the Claude shim over `SKILL.md` and writes metadata through the canonical skill path.

Optional bootstrap commands, only under those preconditions:

```text
python .agents/skills/implement-rfc/scripts/project_config.py
python .agents/skills/implement-rfc/scripts/render_runtime_adapters.py
```

The original bootstrap renderer runs successfully for both prepared contexts. Its inherited test suite has one known false-positive per context: the project-name substring linter rejects ordinary `mask` code and the `agentskills.io` URL. This is explicitly assigned to ASK-0003; record the known result rather than claiming a green seed, skipping all tests, or silently patching the retained source. The adapted skill must pass the repaired check before RFC-ASK-0001 closes.

Keep bootstrap copies out of permanent authoritative source. For newly staged untracked copies, use explicit local Git exclusions as part of bootstrap setup; record exactly which entries were added. Do not hide or erase existing tracked skill files. Bootstrap retirement is MASK-0015, with backups and byte comparison.

## 3. Reconcile and import the packet

On main, under one active integrator **per repository**, reconcile `repositories/<name>/` with the live tree. These are intended additions/scaffolds, not an instruction to overwrite an existing root README, AGENTS.md, board or counter.

Supply/reconcile root instructions, tracker READMEs, project-context files, the RFCs/cards and the two bootstrap scripts from `bootstrap/scripts/`. The gate/allocator scripts are repository support tools, not MASK runtime commands. If a repository already has compatible tracker tools, retain them and update its project facts instead.

For new empty boards, the provisional IDs can be adopted. For existing boards, allocate live IDs with the live allocator and rewrite the live RFC/card filenames, frontmatter, dependencies, index and references consistently. Cross-repository references must be remapped in both handoff records. Do **not** edit this retained packet's original IDs or copy its implementation-order document as a second mutable board.

For each repository:

- retain the original ZIP at `docs/rfcs/assets/mask-v1-2026-09-05/` (outside agent discovery);
- add `mask-v1-2026-09-05.LIVE_IMPORT.md` with original-to-live IDs, import/baseline commit, destinations, exclusions and the other repository's handoff location;
- update NEXT_ID past all allocated IDs and record each closeout's actual `RFC_BASE_SHA` before its source work;
- commit the live import with explicit pathspecs and run `python scripts/verify_documentation.py --root .`;
- reserve any additional lane ID block on main before lane-created cards. Do not allocate from a working lane or recycle IDs.

No copied issue snapshot outranks an existing live board. Every source/card status in this packet is unimplemented; do not infer completed work from detailed acceptance text.

## 4. Follow this cross-repository order

1. **AgentSkills:** RFC-ASK-0001 (ASK-0001 through ASK-0004). First commit imports the clean supplied skill; subsequent commits adapt shared context and safe rendering.
2. **ManageAgentSkills:** RFC-MASK-0001, RFC-MASK-0002, RFC-MASK-0003. Record the upstream skill's integrated commit before beginning.
3. **AgentSkills:** RFC-ASK-0002 (ASK-0005 through ASK-0006). Add manage-agent-skills second, checked against the actual MASK CLI.
4. **ManageAgentSkills:** RFC-MASK-0004. Cut over the two named projects from bootstrap copies to MASK-managed links and finish native CLI/launcher checks.

Native platform work moves into its platform-ready lane when prerequisites are done. Keep an unavailable platform test open rather than labeling it passed. Do not enable remote agent orchestration or fleet synchronization to satisfy these cards; use ordinary separate local sessions if necessary.

## 5. Stop at the stated v1 boundary

The program is stdlib Python plus Git; one source; project declarations; local registry; per-skill links; manual update; JSON API. No marketplace, daemon, multiple source solver, copy mode, global skill inventory, automatic Git push, credential storage or remote device control.

`mask update` affects the shared AgentSkills checkout and every registered consumer. `mask self update` affects ManageAgentSkills only and takes effect on the next invocation. Neither command is permission to publish a private repository.

## Completion report

Use the supplied implement-rfc closeout process. Report live completed cards/commits, exact selected checks, actual Windows/macOS results, two-repository handoff commits, bootstrap retirement/retained backups, remaining limitations and any deferred native cards. Never mark Auto-Verified until the RFC's existing acceptance criteria are satisfied. Keep the next actionable slice on the live closeout card so a new agent can resume without chat history.
