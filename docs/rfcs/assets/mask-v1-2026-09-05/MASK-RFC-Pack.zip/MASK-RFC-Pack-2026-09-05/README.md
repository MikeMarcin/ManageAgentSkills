# MASK — Manage Agent SKills
## Implementation RFC pack · 2026-09-05

**Program:** `MikeMarcin/ManageAgentSkills` · **private skill source:** `MikeMarcin/AgentSkills` · **command:** `mask`

MASK is a small, dependency-free Python CLI that reconciles a project's declared skills with local directory symlinks. One ordinary Git checkout supplies skills. Each machine keeps its own project registry. Updates are explicit and one-way. There is no fleet synchronization service, marketplace, daemon, or credential store.

**Start with [START-HERE.md](START-HERE.md).** The implementation agent uses the supplied BPR `implement-rfc` skill, not a newly invented execution workflow. The clean supplied skill is included as the first AgentSkills seed. Its original project-local assumptions must be adapted before shared deployment; this is the first RFC, not an undocumented prerequisite.

### Contents

| Material | Purpose |
|---|---|
| [IMPLEMENT-MASK.md](IMPLEMENT-MASK.md) | Copy-ready agent handoff covering both repositories |
| [IMPLEMENTATION-ORDER.md](IMPLEMENTATION-ORDER.md) | Dependency order and cross-repository handoffs; import-time reference, not a second live board |
| [DECISIONS.md](DECISIONS.md) | Settled scope and corrections to earlier discussion |
| `repositories/ManageAgentSkills/docs/` | Four MASK RFCs, implementation cards, closeout cards, tracker rules and architecture contracts |
| `repositories/AgentSkills/docs/` | Two AgentSkills RFCs and their own implementation/closeout cards |
| `repositories/*/.mask/skill-config/implement-rfc/` | Ready-to-use project facts and rules for the shared workflow |
| `seeds/AgentSkills/skills/implement-rfc/` | Clean, unchanged source files from the supplied skill archive |
| `templates/` | JSON examples, schemas, and the second skill's authoring brief |
| `bootstrap/` | Temporary project-local executor instructions and small tracker-support utilities |
| `tools/validate_pack.py` | Validate this downloaded pack, not the future MASK application |
| [SOURCE-REVIEW.md](SOURCE-REVIEW.md) | Attachment findings, provenance and research boundaries |
| [PACK-VALIDATION.md](PACK-VALIDATION.md) | Packet checks, bootstrap smoke results and the inherited linter defect |
| [REFERENCES.md](REFERENCES.md) | Primary technical sources checked for the design |

### Intended end state

```text
ManageAgentSkills/                    AgentSkills/
  mask.py                              skills/
  tests/                                 implement-rfc/
  schemas/                               manage-agent-skills/
  docs/                                docs/
  .mask.json                           .mask.json
  .mask/skill-config/...                .mask/skill-config/...
              \                         /
               project-local symlinks
                         |
             one machine-local AgentSkills checkout
```

Every consuming project commits only `.mask.json` and any workflow-specific project context. Generated links remain local and ignored. A fresh machine needs a clone of each repository and one explicit registration per project. Nothing automatically pushes skill edits or synchronizes local state.

### Delivery status

This is a **design and task pack**, not a finished MASK implementation. RFCs are `Proposed`; all implementation and native-platform acceptance remains to be performed. The packet's validator checks packet consistency only. `RFC_BASE_SHA`, implementation commits and runtime results are deliberately unset.

The two GitHub repository metadata reads returned 404 during preparation. That does not distinguish nonexistent repositories from inaccessible private repositories. The importer must inspect the actual authorized checkouts and must not overwrite an existing repository or infer authority to publish one.

### Privacy

The supplied skill contains BPR project rules, runtime-routing references, and scripts. Keep this pack and the AgentSkills seed private by default. Nothing in this pack authorizes publishing either repository, assigning a new license to inherited files, or changing BetterPullReview in place.
