# Primary technical references

Checked 2026-09-05. These references establish platform behavior; MASK's JSON API and safety policy are project design decisions, not an existing standard.

1. **OpenAI — Build skills**, sections “Where Codex loads local skills” and “Enable or disable local Codex skills.” Repository discovery includes `.agents/skills`; symlinked skill folders are supported. Filesystem presence and explicit disable settings are different layers. https://learn.chatgpt.com/docs/build-skills
2. **Anthropic — Extend Claude with skills.** Project skills use `.claude/skills`; individual entries can be symlinks. The `synced` skill-folder name is reserved. Loading is still subject to runtime/trust behavior. https://code.claude.com/docs/en/skills
3. **Python 3.11 — os.** `os.symlink(..., target_is_directory=True)` supports directory symlinks; Windows needs Developer Mode or appropriate privileges. `lstat`/`readlink` inspect links; replacing one file is not a multi-file transaction. https://docs.python.org/3.11/library/os.html
4. **Python 3.11 — subprocess.** Use argument vectors with `shell=False`, captured output and bounded waits; timeout/process-tree cleanup must be treated explicitly. https://docs.python.org/3.11/library/subprocess.html
5. **Git — git-merge.** `--ff-only` refuses a non-fast-forward merge; it is not a dry-run or checkout transaction. https://git-scm.com/docs/git-merge
6. **Git — git.** `GIT_TERMINAL_PROMPT=0` suppresses Git terminal authentication prompts, and `GIT_OPTIONAL_LOCKS=0` avoids optional index refresh locks for observational commands. They are not universal guarantees about arbitrary credential helpers. https://git-scm.com/docs/git

The exact helper entrypoints and portability findings in SOURCE-REVIEW.md come from the attached archive, whose clean source is included. Its routing/model defaults are inherited source, not a new endorsement of model availability. Verify a selected optional runtime before using it; missing optional delegation does not block ordinary local implementation.
