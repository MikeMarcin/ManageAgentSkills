# Second skill authoring brief

Create `AgentSkills/skills/manage-agent-skills/SKILL.md` only after the first implement-rfc import and the MASK CLI integration handoff. Follow RFC-ASK-0002. Use `name: manage-agent-skills` and a nonempty single-line description matching MASK's frontmatter subset.

Keep the body short and procedural. Include capabilities discovery, project inspection, incremental require/unrequire, exact-set intent, dry-run/plan guard, JSON/error interpretation, explicit update scope, safe recovery/adoption and final convergence reporting. Never recommend changing state.json by hand or bypassing a collision. The agent follows the user's requested scope; knowledge of an update command is not authority to use it everywhere.

Do not copy the entire CLI reference into the skill. Include a small command sequence and point to ManageAgentSkills' docs for advanced cases. Validate every example against the actual capabilities output. The first version is project-scoped; adding a global deployment subsystem is not part of this work.
