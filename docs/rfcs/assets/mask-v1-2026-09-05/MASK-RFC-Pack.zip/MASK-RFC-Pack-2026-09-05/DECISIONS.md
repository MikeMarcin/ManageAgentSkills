# Decisions and boundaries

These decisions are the implementation baseline. RFCs refine mechanics without reopening the product direction.

| ID | Decision |
|---|---|
| D01 | Product `MASK`, executable `mask`, expansion **Manage Agent SKills**. |
| D02 | Program repository is exactly `MikeMarcin/ManageAgentSkills`; skill repository is exactly `MikeMarcin/AgentSkills`. They are separate Git histories. |
| D03 | Import the attached portable BPR `implement-rfc` as the **first skill** in AgentSkills. Build using that workflow. Add `manage-agent-skills` second, after MASK's public CLI exists. |
| D04 | Python 3.11+ and the standard library only at runtime. Git is an external prerequisite. Prefer a single readable `mask.py`; a handful of cohesive modules is acceptable only when tests and clarity benefit. No framework, server, plugin SDK or YAML dependency. |
| D05 | Checked-in project declaration `.mask.json`; project-local workflow context `.mask/skill-config/implement-rfc/{project.json,project.md}`; machine-local `~/.mask/{config.json,state.json,operation.lock,pending.json}`. `MASK_HOME` relocates machine state for isolation. |
| D06 | Exactly one configured local AgentSkills checkout per machine, with `skills/<id>/SKILL.md`. The project declaration names skills, not a private Git URL. No per-project version pinning in v1. |
| D07 | Directory symlinks only, per skill. Native Windows symlink privileges are a documented prerequisite. No silent copy/junction fallback and no wholesale replacement of agent skill roots. |
| D08 | Fixed v1 targets: Claude `.claude/skills`, Codex `.agents/skills`. Paths live in one adapter table, not scattered code. No agent auto-detection or manipulation of agent permissions/enabled-skill settings. |
| D09 | Explicit `mask update` fetches/validates/fast-forwards **AgentSkills** and reconciles registered projects. `mask self update` updates **ManageAgentSkills** only. They never implicitly update each other. |
| D10 | Agent management uses deterministic, noninteractive CLI commands, versioned JSON, stable error codes, dry runs, explicit exact-set versus incremental edits, and stale-plan checks. No normal operation requires hand-editing internal state. |
| D11 | Existing files, directories, unknown symlinks, junctions and changed owned links are collisions. Never infer ownership from a pathname or matching skill name. There is no generic `--force`. |
| D12 | A missing recorded link can be recreated; a broken link can be repaired only if its raw link value still matches the ownership record. A link changed to another destination is **not** automatically repaired. |
| D13 | `--dry-run` and `plan` are local, observational operations: `changed=false`, `would_change` reports the proposal. Refreshing remote information is a separate explicit `source fetch`. No dry-run fetch, clone, journal or lock-file creation. |
| D14 | No claim of atomicity across filesystem links, two JSON files, Git checkout and multiple projects. Preflight, minimal recovery intent, narrow rollback and truthful partial reporting are sufficient. |
| D15 | The supplied workflow must read context from the **consumer project**, never infer it from the resolved shared skill location. Generated adapters must never write through a shared skill symlink. |
| D16 | The workflow's native role adapters remain optional. MASK never executes a skill's installer, renderer, scripts, hooks, or routing metadata during deploy/update. |
| D17 | No unattended fleet updates, automatic commits/pushes, bidirectional merging, remote device registry, profiles, dependency solver, plugin marketplace, GUI, or MCP server. |
| D18 | Existing BPR/PlaceOfMind copies are not deleted or migrated automatically. Named migrations are explicit, backed up, checked and scoped; public distribution is a later publication decision. |

## Clarifications relative to the conversation

**Separate repositories remove the need for update-time re-execution.** The earlier combined-repository proposal updated program and skills together. Here, `mask self update` finishes using the already-loaded code and reports `next_invocation_required=true`. It must not chain into `apply`, load updated modules midway, or restart itself automatically. The next normal invocation uses the new program.

**Dry-run success is not a mutation.** `changed` always reports actual persistent changes at return; `would_change` reports a plan. A plan never returns `changed=true` simply because it contains actions.

**An ownership record is necessary but not sufficient.** Before unlinking, both the current leaf type and its recorded raw link value must still agree. An unexpected link destination is drift, not permission to delete.

**The existing skill renderer is not safe behind two skill symlinks.** It writes a Claude shim into `.../implement-rfc/SKILL.md` and generated metadata into the canonical skill path. The first AgentSkills RFC separates source assets, project context and project-local generated outputs.

**Availability is not load verification.** MASK reports filesystem deployment, not that Claude/Codex enabled or loaded a skill. A disabled host setting, trust prompt, or required restart is outside MASK's authority. Native smoke checks verify the selected integration rather than equating a symlink with model behavior.

**Self-authorship is not a security guarantee.** The trust claim is a bounded, tested write surface. MASK is not a sandbox against hostile local processes, malicious skill text, compromised Git credentials or arbitrary user-configured Git filters. Scope and residual risks are explicit in RFC-MASK-0002/0003.
