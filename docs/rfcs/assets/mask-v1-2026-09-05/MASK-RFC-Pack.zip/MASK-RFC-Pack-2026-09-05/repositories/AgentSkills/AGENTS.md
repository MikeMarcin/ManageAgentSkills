# AgentSkills: agent instructions

Read README.md, CONTRIBUTING.md, docs/rfcs/README.md, docs/issues/README.md, the requested live RFC and card, and the nearest nested AGENTS.md. Use the portable implement-rfc workflow with this repository's `.mask/skill-config/implement-rfc/` context. Before the shared resolver exists, follow the packet's explicit two-file bootstrap customization.

This is the private canonical skill library. implement-rfc is imported first; manage-agent-skills second. Program runtime code belongs in ManageAgentSkills.

Routine skill management uses `mask ... --json`, or the known absolute Python entrypoint if PATH is not configured. Inspect capabilities/state and preview meaningful changes. Preserve incremental versus exact-set intent. Never edit MASK's internal state or bypass a collision with destructive shell commands.

Preserve unrelated changes; stage explicit paths. No publication, credential grants, permission changes, unrequested Git push or migration of BPR/PlaceOfMind. Test in temporary fixture roots/local bare remotes. No daemon, fleet sync, marketplace, force overwrite or copy fallback. Reorient from live boards and recorded closeouts after interruption.
