# Packet validation and bootstrap findings

Checked during packet preparation on 2026-09-05. These results concern the downloaded design/scaffolding and the supplied executor only; **MASK is not implemented or acceptance-tested by this pack**.

| Check | Result |
|---|---|
| Packet inventory, unique IDs, dependency graph and closeout coverage | Passed: 6 RFCs, 24 cards, no missing/cyclic dependencies |
| Clean supplied seed provenance | Passed: all 39 files match the archive bytes and original portable-manifest entries; no resource forks or caches retained |
| Project-context configuration parsing | Passed for both ManageAgentSkills and AgentSkills |
| Original renderer in disposable real-directory bootstrap copies | Passed for both contexts; 17 generated files each; no shared symlinks or live user projects involved |
| Supplied `test_project_config.py` | Passed: 6 tests in each prepared context |
| Supplied `test_render_runtime_adapters.py` | 8 passed, 1 failed in each context: the inherited name-substring linter described below |
| Repository documentation structure gates | Passed: MASK 4 RFCs / 18 cards; AgentSkills 2 RFCs / 6 cards |
| JSON Schema definitions and example validation | Passed for the three schemas and six supplied example documents using authoring-time jsonschema; the product gains no dependency |
| Python syntax for included support utilities | Passed |
| Bootstrap issue allocator | Passed dry-run, two-ID reservation and off-main refusal in a disposable Git repository |
| Packet-level Markdown navigation | Passed |
| Actual MASK CLI, shared adaptation, native Windows/macOS, GitHub onboarding | Not run: implementation and native acceptance tasks remain open |

## Known inherited linter defect — implementation task ASK-0003

The existing `test_portable_sources_name_no_project` rejects any case-insensitive occurrence of the consumer's name in portable files. In the MASK context it mistakes ordinary WebSocket `mask` variables in `codex_station.py` for a project dependency. In the AgentSkills context it rejects `https://agentskills.io/...` in the skill's standards references.

Neither failure means bootstrap root selection or renderer execution failed. Neither justifies declaring the inherited suite green. The retained seed remains byte-identical; RFC-ASK-0001 and ASK-0003 explicitly require scoped coupling checks with both positive and negative regression cases, and full relevant passing evidence before closing that RFC.

## Re-run local packet checks

```text
python tools/validate_pack.py
python bootstrap/scripts/verify_documentation.py --root repositories/ManageAgentSkills
python bootstrap/scripts/verify_documentation.py --root repositories/AgentSkills
```

Run from the extracted packet root. These commands validate the packet, not the future application. Optional original-skill smoke tests must use disposable copies because the original renderer writes generated adapters and source metadata.
